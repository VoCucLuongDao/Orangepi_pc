export VDPAU_OSD=1
