# This should fix
# perl: warning: Setting locale failed.

export LC_ALL=$LANG
